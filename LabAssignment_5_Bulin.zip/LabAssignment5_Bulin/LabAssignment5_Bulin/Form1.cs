﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabAssignment5_Bulin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            //In order to get the file to be read I had to use the System.IO plugin
            //The file is read in authentication.txt was moved into the /debug file folder section. If it is not there it breaks a lot of stuff. 
            // Ensure the file exists
            string filePath = "authentication.txt";
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Authentication file not found. Please contact the administrator.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Read the file and search for the username and password
            //set the boolean to false first or it will always remain true without need for a login process
            bool isAuthenticated = false;
            //tries to use these characters to match username:password splitting on those lines. 
            try
            {
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    //After it splits it needs to be good at both of these in order for it to be true, to pass through
                    string[] credentials = line.Split(':');
                    if (credentials.Length == 2 && credentials[0] == username && credentials[1] == password)
                    {
                        isAuthenticated = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while processing the file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Display appropriate message
            if (isAuthenticated)
            {
                MessageBox.Show("Login succeeds!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Login failed. Please try it again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
        

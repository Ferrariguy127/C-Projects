﻿namespace BMICalculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CalculateBMI = new Button();
            lblWeight = new Label();
            lblHeight = new Label();
            lblft = new Label();
            lblinches = new Label();
            txtWeight = new TextBox();
            txtHeight = new TextBox();
            txtInches = new TextBox();
            txtBMI = new TextBox();
            lblBMI = new Label();
            SuspendLayout();
            // 
            // CalculateBMI
            // 
            CalculateBMI.BackColor = SystemColors.InactiveCaption;
            CalculateBMI.Location = new Point(237, 318);
            CalculateBMI.Name = "CalculateBMI";
            CalculateBMI.Size = new Size(274, 57);
            CalculateBMI.TabIndex = 0;
            CalculateBMI.Text = "Calculate (BMI)";
            CalculateBMI.UseVisualStyleBackColor = false;
            CalculateBMI.Click += button1_Click;
            // 
            // lblWeight
            // 
            lblWeight.AutoSize = true;
            lblWeight.Location = new Point(85, 101);
            lblWeight.Name = "lblWeight";
            lblWeight.Size = new Size(141, 32);
            lblWeight.TabIndex = 3;
            lblWeight.Text = "Weight (lbs)";
            // 
            // lblHeight
            // 
            lblHeight.AutoSize = true;
            lblHeight.Location = new Point(140, 187);
            lblHeight.Name = "lblHeight";
            lblHeight.Size = new Size(86, 32);
            lblHeight.TabIndex = 4;
            lblHeight.Text = "Height";
            // 
            // lblft
            // 
            lblft.AutoSize = true;
            lblft.Location = new Point(321, 193);
            lblft.Name = "lblft";
            lblft.Size = new Size(35, 32);
            lblft.TabIndex = 5;
            lblft.Text = "ft.";
            // 
            // lblinches
            // 
            lblinches.AutoSize = true;
            lblinches.Location = new Point(523, 193);
            lblinches.Name = "lblinches";
            lblinches.Size = new Size(82, 32);
            lblinches.TabIndex = 6;
            lblinches.Text = "inches";
            // 
            // txtWeight
            // 
            txtWeight.Location = new Point(261, 102);
            txtWeight.Name = "txtWeight";
            txtWeight.Size = new Size(250, 39);
            txtWeight.TabIndex = 7;
            txtWeight.TextChanged += txtWeight_TextChanged;
            // 
            // txtHeight
            // 
            txtHeight.Location = new Point(261, 189);
            txtHeight.Name = "txtHeight";
            txtHeight.Size = new Size(54, 39);
            txtHeight.TabIndex = 8;
            // 
            // txtInches
            // 
            txtInches.Location = new Point(417, 186);
            txtInches.Name = "txtInches";
            txtInches.Size = new Size(94, 39);
            txtInches.TabIndex = 9;
            // 
            // txtBMI
            // 
            txtBMI.Location = new Point(344, 427);
            txtBMI.Name = "txtBMI";
            txtBMI.Size = new Size(167, 39);
            txtBMI.TabIndex = 10;
            // 
            // lblBMI
            // 
            lblBMI.AutoSize = true;
            lblBMI.Location = new Point(237, 434);
            lblBMI.Name = "lblBMI";
            lblBMI.Size = new Size(56, 32);
            lblBMI.TabIndex = 11;
            lblBMI.Text = "BMI";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(765, 500);
            Controls.Add(lblBMI);
            Controls.Add(txtBMI);
            Controls.Add(txtInches);
            Controls.Add(txtHeight);
            Controls.Add(txtWeight);
            Controls.Add(lblinches);
            Controls.Add(lblft);
            Controls.Add(lblHeight);
            Controls.Add(lblWeight);
            Controls.Add(CalculateBMI);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button CalculateBMI;
        private Label lblWeight;
        private Label lblHeight;
        private Label lblft;
        private Label lblinches;
        private TextBox txtWeight;
        private TextBox txtHeight;
        private TextBox txtInches;
        private TextBox txtBMI;
        private Label lblBMI;
    }
}
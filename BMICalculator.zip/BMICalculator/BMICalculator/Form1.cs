namespace BMICalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            float Weight;
            float Height;
            float inches;
            float BMI;
            float TotalHeight;

            Weight = float.Parse(txtWeight.Text);
            Height = float.Parse(txtHeight.Text);
            inches = float.Parse(txtInches.Text);
            TotalHeight = Height * 12 + inches;

            BMI = Weight / (TotalHeight * TotalHeight) * 703;

            txtBMI.Text = BMI.ToString();

        }

        private void Weight_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtWeight_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
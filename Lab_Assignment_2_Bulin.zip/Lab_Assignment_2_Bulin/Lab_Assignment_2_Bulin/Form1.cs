﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_Assignment_2_Bulin
{
    public partial class HypotheticalIncomeTax : Form
    {
        public HypotheticalIncomeTax()
        {
            InitializeComponent();
        }

        private void btnCalculateTax_Click(object sender, EventArgs e)
        {
            // Assuming the annual income is taken from a TextBox control named txtAnnualIncome
            double annualIncome = Convert.ToDouble(txtAnnualIncome.Text);
            double taxRate = 0;
            double taxAmount = 0;

            // Determine the tax rate based on the numbers from the table
            if (annualIncome <= 30000)
            {
                taxRate = 0.05;  // 5%
            }
            else if (annualIncome > 30000 && annualIncome <= 60000)
            {
                taxRate = 0.10;  // 10%
            }
            else if (annualIncome > 60000 && annualIncome <= 120000)
            {
                taxRate = 0.15;  // 15%
            }
            else if (annualIncome > 120000)
            {
                taxRate = 0.20;  // 20%
            }

            // Calculate the tax amount
            taxAmount = annualIncome * taxRate;

            // Display the tax amount (assuming a label lblTaxAmount for output)
            txtTaxAmount.Text = "$" + taxAmount.ToString("N2");
            txtTaxRate.Text = (taxRate * 100).ToString("N2");
        }
    }
}

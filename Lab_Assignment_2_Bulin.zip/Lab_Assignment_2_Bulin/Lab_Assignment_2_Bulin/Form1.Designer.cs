﻿namespace Lab_Assignment_2_Bulin
{
    partial class HypotheticalIncomeTax
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAnnualIncome = new System.Windows.Forms.Label();
            this.txtAnnualIncome = new System.Windows.Forms.TextBox();
            this.lblTaxRate = new System.Windows.Forms.Label();
            this.txtTaxRate = new System.Windows.Forms.TextBox();
            this.txtTaxAmount = new System.Windows.Forms.TextBox();
            this.lblTaxAmount = new System.Windows.Forms.Label();
            this.btnCalculateTax = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAnnualIncome
            // 
            this.lblAnnualIncome.AutoSize = true;
            this.lblAnnualIncome.Location = new System.Drawing.Point(77, 97);
            this.lblAnnualIncome.Name = "lblAnnualIncome";
            this.lblAnnualIncome.Size = new System.Drawing.Size(192, 25);
            this.lblAnnualIncome.TabIndex = 0;
            this.lblAnnualIncome.Text = "Annual Income ($) ";
            // 
            // txtAnnualIncome
            // 
            this.txtAnnualIncome.Location = new System.Drawing.Point(374, 97);
            this.txtAnnualIncome.Name = "txtAnnualIncome";
            this.txtAnnualIncome.Size = new System.Drawing.Size(182, 31);
            this.txtAnnualIncome.TabIndex = 1;
            // 
            // lblTaxRate
            // 
            this.lblTaxRate.AutoSize = true;
            this.lblTaxRate.Location = new System.Drawing.Point(82, 187);
            this.lblTaxRate.Name = "lblTaxRate";
            this.lblTaxRate.Size = new System.Drawing.Size(138, 25);
            this.lblTaxRate.TabIndex = 2;
            this.lblTaxRate.Text = "Tax Rate (%)";
            // 
            // txtTaxRate
            // 
            this.txtTaxRate.Location = new System.Drawing.Point(286, 187);
            this.txtTaxRate.Name = "txtTaxRate";
            this.txtTaxRate.Size = new System.Drawing.Size(116, 31);
            this.txtTaxRate.TabIndex = 3;
            // 
            // txtTaxAmount
            // 
            this.txtTaxAmount.Location = new System.Drawing.Point(657, 180);
            this.txtTaxAmount.Name = "txtTaxAmount";
            this.txtTaxAmount.Size = new System.Drawing.Size(137, 31);
            this.txtTaxAmount.TabIndex = 4;
            // 
            // lblTaxAmount
            // 
            this.lblTaxAmount.AutoSize = true;
            this.lblTaxAmount.Location = new System.Drawing.Point(449, 186);
            this.lblTaxAmount.Name = "lblTaxAmount";
            this.lblTaxAmount.Size = new System.Drawing.Size(159, 25);
            this.lblTaxAmount.TabIndex = 5;
            this.lblTaxAmount.Text = "Tax Amount ($)";
            // 
            // btnCalculateTax
            // 
            this.btnCalculateTax.Location = new System.Drawing.Point(286, 343);
            this.btnCalculateTax.Name = "btnCalculateTax";
            this.btnCalculateTax.Size = new System.Drawing.Size(322, 65);
            this.btnCalculateTax.TabIndex = 6;
            this.btnCalculateTax.Text = "Calculate Estimated Tax";
            this.btnCalculateTax.UseVisualStyleBackColor = true;
            this.btnCalculateTax.Click += new System.EventHandler(this.btnCalculateTax_Click);
            // 
            // HypotheticalIncomeTax
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(887, 533);
            this.Controls.Add(this.btnCalculateTax);
            this.Controls.Add(this.lblTaxAmount);
            this.Controls.Add(this.txtTaxAmount);
            this.Controls.Add(this.txtTaxRate);
            this.Controls.Add(this.lblTaxRate);
            this.Controls.Add(this.txtAnnualIncome);
            this.Controls.Add(this.lblAnnualIncome);
            this.Name = "HypotheticalIncomeTax";
            this.Text = "Hypothetical Income Tax";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAnnualIncome;
        private System.Windows.Forms.TextBox txtAnnualIncome;
        private System.Windows.Forms.Label lblTaxRate;
        private System.Windows.Forms.TextBox txtTaxRate;
        private System.Windows.Forms.TextBox txtTaxAmount;
        private System.Windows.Forms.Label lblTaxAmount;
        private System.Windows.Forms.Button btnCalculateTax;
    }
}


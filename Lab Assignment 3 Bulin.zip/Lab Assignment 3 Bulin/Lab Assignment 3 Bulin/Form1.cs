﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Lab_Assignment_3_Bulin
    //Basic Code overview.
    //Simple program that generates a random number given parameters in guessedNumber and the mskboxInt then compares them 
    //and returns the number of guesses it had to generate through. Shown by Guess Count, Next to # of Guesses. 
    {
        public partial class Form1 : Form
        {
            private Random rnd;

            public Form1()
            {
                InitializeComponent();
                rnd = new Random(); // Initialize random number generator
            }

            private void btnRandomlyGuess_Click(object sender, EventArgs e)
            {
                // Get the user's input from the masked text box
                if (int.TryParse(mskboxInt.Text, out int target) && target >= 0 && target <= 999)
                {
                // The guessCount is the number displayed at the bottom of the page. Will display how many times this had to
                //run in order to match the user provided number.
                    int guessCount = 0;
                    int guessedNumber = -1;

                    // Loop until the guessed number matches the target
                    while (guessedNumber != target)
                    {
                    //Generates a number between 100-999 since these are all possible 3 digit numbers. 
                        guessedNumber = rnd.Next(100, 999);
                        guessCount++;
                    }

                    // Display the number of guesses taken in the txtCount TextBox
                    txtCount.Text = guessCount.ToString();
                }
                else
                {
                    MessageBox.Show("Please enter a valid 3-digit integer.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            private void mskboxInt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
            {
                
            }

            private void txtCount_TextChanged(object sender, EventArgs e)
            {
            
            }
        }
    }
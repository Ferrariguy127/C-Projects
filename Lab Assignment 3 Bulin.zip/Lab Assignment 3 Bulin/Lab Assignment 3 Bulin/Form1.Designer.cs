﻿namespace Lab_Assignment_3_Bulin
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEnterNumber = new System.Windows.Forms.Label();
            this.btnRandomlyGuess = new System.Windows.Forms.Button();
            this.lblNumGuesses = new System.Windows.Forms.Label();
            this.mskboxInt = new System.Windows.Forms.MaskedTextBox();
            this.txtCount = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblEnterNumber
            // 
            this.lblEnterNumber.AutoSize = true;
            this.lblEnterNumber.Location = new System.Drawing.Point(116, 134);
            this.lblEnterNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEnterNumber.Name = "lblEnterNumber";
            this.lblEnterNumber.Size = new System.Drawing.Size(382, 31);
            this.lblEnterNumber.TabIndex = 0;
            this.lblEnterNumber.Text = "Enter a 3-digit integer";
            // 
            // btnRandomlyGuess
            // 
            this.btnRandomlyGuess.Location = new System.Drawing.Point(320, 244);
            this.btnRandomlyGuess.Name = "btnRandomlyGuess";
            this.btnRandomlyGuess.Size = new System.Drawing.Size(250, 64);
            this.btnRandomlyGuess.TabIndex = 1;
            this.btnRandomlyGuess.Text = "Randomly Guess";
            this.btnRandomlyGuess.UseVisualStyleBackColor = true;
            this.btnRandomlyGuess.Click += new System.EventHandler(this.btnRandomlyGuess_Click);
            // 
            // lblNumGuesses
            // 
            this.lblNumGuesses.AutoSize = true;
            this.lblNumGuesses.Location = new System.Drawing.Point(121, 342);
            this.lblNumGuesses.Name = "lblNumGuesses";
            this.lblNumGuesses.Size = new System.Drawing.Size(206, 31);
            this.lblNumGuesses.TabIndex = 3;
            this.lblNumGuesses.Text = "# of guesses";
            // 
            // mskboxInt
            // 
            this.mskboxInt.Location = new System.Drawing.Point(523, 134);
            this.mskboxInt.Mask = "000";
            this.mskboxInt.Name = "mskboxInt";
            this.mskboxInt.Size = new System.Drawing.Size(72, 38);
            this.mskboxInt.TabIndex = 4;
            this.mskboxInt.ValidatingType = typeof(int);
            this.mskboxInt.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mskboxInt_MaskInputRejected);
            // 
            // txtCount
            // 
            this.txtCount.Location = new System.Drawing.Point(407, 342);
            this.txtCount.Name = "txtCount";
            this.txtCount.ReadOnly = true;
            this.txtCount.Size = new System.Drawing.Size(100, 38);
            this.txtCount.TabIndex = 5;
            this.txtCount.TextChanged += new System.EventHandler(this.txtCount_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(838, 548);
            this.Controls.Add(this.txtCount);
            this.Controls.Add(this.mskboxInt);
            this.Controls.Add(this.lblNumGuesses);
            this.Controls.Add(this.btnRandomlyGuess);
            this.Controls.Add(this.lblEnterNumber);
            this.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Randomly Guessing a Number";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEnterNumber;
        private System.Windows.Forms.Button btnRandomlyGuess;
        private System.Windows.Forms.Label lblNumGuesses;
        private System.Windows.Forms.MaskedTextBox mskboxInt;
        private System.Windows.Forms.TextBox txtCount;
    }
}


﻿namespace Assignment_1_David_Bulin
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblCustomerName = new Label();
            txtCustomerName = new TextBox();
            txtLaborHours = new TextBox();
            lblHoursOfLabor = new Label();
            btnDisplayBill = new Button();
            lblCostOfParts = new Label();
            txtCostOfParts = new TextBox();
            listBoxFinalBill = new ListBox();
            SuspendLayout();
            // 
            // lblCustomerName
            // 
            lblCustomerName.AutoSize = true;
            lblCustomerName.Location = new Point(79, 83);
            lblCustomerName.Name = "lblCustomerName";
            lblCustomerName.Size = new Size(188, 32);
            lblCustomerName.TabIndex = 0;
            lblCustomerName.Text = "Customer Name";
            lblCustomerName.Click += label1_Click;
            // 
            // txtCustomerName
            // 
            txtCustomerName.Location = new Point(327, 83);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.Size = new Size(200, 39);
            txtCustomerName.TabIndex = 1;
            // 
            // txtLaborHours
            // 
            txtLaborHours.Location = new Point(327, 208);
            txtLaborHours.Name = "txtLaborHours";
            txtLaborHours.Size = new Size(200, 39);
            txtLaborHours.TabIndex = 2;
            // 
            // lblHoursOfLabor
            // 
            lblHoursOfLabor.AutoSize = true;
            lblHoursOfLabor.Location = new Point(79, 208);
            lblHoursOfLabor.Name = "lblHoursOfLabor";
            lblHoursOfLabor.Size = new Size(172, 32);
            lblHoursOfLabor.TabIndex = 3;
            lblHoursOfLabor.Text = "Hours of Labor";
            // 
            // btnDisplayBill
            // 
            btnDisplayBill.Location = new Point(576, 118);
            btnDisplayBill.Name = "btnDisplayBill";
            btnDisplayBill.Size = new Size(142, 76);
            btnDisplayBill.TabIndex = 4;
            btnDisplayBill.Text = "Display Bill";
            btnDisplayBill.UseVisualStyleBackColor = true;
            btnDisplayBill.Click += btnDisplayBill_Click;
            // 
            // lblCostOfParts
            // 
            lblCostOfParts.AutoSize = true;
            lblCostOfParts.Location = new Point(81, 279);
            lblCostOfParts.Name = "lblCostOfParts";
            lblCostOfParts.Size = new Size(151, 32);
            lblCostOfParts.TabIndex = 5;
            lblCostOfParts.Text = "Cost Of Parts";
            // 
            // txtCostOfParts
            // 
            txtCostOfParts.Location = new Point(327, 272);
            txtCostOfParts.Name = "txtCostOfParts";
            txtCostOfParts.Size = new Size(200, 39);
            txtCostOfParts.TabIndex = 6;
            // 
            // listBoxFinalBill
            // 
            listBoxFinalBill.FormattingEnabled = true;
            listBoxFinalBill.ItemHeight = 32;
            listBoxFinalBill.Location = new Point(86, 351);
            listBoxFinalBill.Name = "listBoxFinalBill";
            listBoxFinalBill.Size = new Size(569, 164);
            listBoxFinalBill.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(887, 644);
            Controls.Add(listBoxFinalBill);
            Controls.Add(txtCostOfParts);
            Controls.Add(lblCostOfParts);
            Controls.Add(btnDisplayBill);
            Controls.Add(lblHoursOfLabor);
            Controls.Add(txtLaborHours);
            Controls.Add(txtCustomerName);
            Controls.Add(lblCustomerName);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCustomerName;
        private TextBox txtCustomerName;
        private TextBox txtLaborHours;
        private Label lblHoursOfLabor;
        private Button btnDisplayBill;
        private Label lblCostOfParts;
        private TextBox txtCostOfParts;
        private ListBox listBoxFinalBill;
    }
}
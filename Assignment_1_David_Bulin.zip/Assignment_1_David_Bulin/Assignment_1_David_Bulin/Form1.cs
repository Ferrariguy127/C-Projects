namespace Assignment_1_David_Bulin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnDisplayBill_Click(object sender, EventArgs e)
        {
            //Since we are using different datatypes a try catch may help with diagnosis later. 
            try
            {
                //constant variables we don't want changed between calculations
                const double laborRate = 75.00;
                const double salesTaxRate = 0.05;

                // Get input values
                string customerName = txtCustomerName.Text;
                int hoursOfLabor = int.Parse(txtLaborHours.Text);
                double costOfParts = double.Parse(txtCostOfParts.Text);

                // Calculate costs
                double laborCost = hoursOfLabor * laborRate;
                double totalCostBeforeTax = laborCost + costOfParts;
                double totalCostWithTax = totalCostBeforeTax + (totalCostBeforeTax * salesTaxRate);

                // Clear the ListBox before displaying new values
                listBoxFinalBill.Items.Clear();

                // Display bill in ListBox
                // Add customer name
                listBoxFinalBill.Items.Add(string.Format("{0, -40} {1, 10}", "Customer Name:", customerName));
                // Add dash line to seperate Name from bill totals
                listBoxFinalBill.Items.Add("--------------------------------------------------");
                // Add labor cost
                listBoxFinalBill.Items.Add(string.Format("{0, -40} {1, 15:C}", "Labor Cost:", laborCost));
                // Add part cost
                listBoxFinalBill.Items.Add(string.Format("{0, -40} {1, 16:C}", "Part Cost:", costOfParts));
                // Add total charge (with tax)
                listBoxFinalBill.Items.Add(string.Format("{0, -40} {1, 9:C}", "Total Charge (incl. Sales Tax):", totalCostWithTax));

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);        // Display runtime errors (exception) in a messagebox.
                // Commerical software write an error log file here!
            }
        }
    }
}
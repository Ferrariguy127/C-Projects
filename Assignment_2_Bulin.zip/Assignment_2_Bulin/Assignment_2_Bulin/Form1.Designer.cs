﻿namespace Assignment_2_Bulin
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInformationSystemsDevelopment = new System.Windows.Forms.Label();
            this.lblAssignment1 = new System.Windows.Forms.Label();
            this.lblAssignment2 = new System.Windows.Forms.Label();
            this.lblMidTermExam = new System.Windows.Forms.Label();
            this.lblFinalExam = new System.Windows.Forms.Label();
            this.lblAssignment1TotalScore = new System.Windows.Forms.Label();
            this.lblAssignment2TotalScore = new System.Windows.Forms.Label();
            this.lblMidtermExamTotalScore = new System.Windows.Forms.Label();
            this.lblFinalExamTotalScore = new System.Windows.Forms.Label();
            this.txtAssignment1Score = new System.Windows.Forms.TextBox();
            this.txtBoxAssignment2Score = new System.Windows.Forms.TextBox();
            this.txtMidtermExamScore = new System.Windows.Forms.TextBox();
            this.txtBoxFinalExamScore = new System.Windows.Forms.TextBox();
            this.lblLETTERGRADE = new System.Windows.Forms.Label();
            this.txtFinalGradeLetter = new System.Windows.Forms.TextBox();
            this.btnFinalGradeCalculate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblInformationSystemsDevelopment
            // 
            this.lblInformationSystemsDevelopment.AutoSize = true;
            this.lblInformationSystemsDevelopment.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformationSystemsDevelopment.Location = new System.Drawing.Point(117, 70);
            this.lblInformationSystemsDevelopment.Name = "lblInformationSystemsDevelopment";
            this.lblInformationSystemsDevelopment.Size = new System.Drawing.Size(775, 36);
            this.lblInformationSystemsDevelopment.TabIndex = 0;
            this.lblInformationSystemsDevelopment.Text = "MIS200 - Information Systems Development";
            // 
            // lblAssignment1
            // 
            this.lblAssignment1.AutoSize = true;
            this.lblAssignment1.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssignment1.Location = new System.Drawing.Point(141, 187);
            this.lblAssignment1.Name = "lblAssignment1";
            this.lblAssignment1.Size = new System.Drawing.Size(206, 31);
            this.lblAssignment1.TabIndex = 1;
            this.lblAssignment1.Text = "Assignment 1";
            // 
            // lblAssignment2
            // 
            this.lblAssignment2.AutoSize = true;
            this.lblAssignment2.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssignment2.Location = new System.Drawing.Point(141, 262);
            this.lblAssignment2.Name = "lblAssignment2";
            this.lblAssignment2.Size = new System.Drawing.Size(206, 31);
            this.lblAssignment2.TabIndex = 2;
            this.lblAssignment2.Text = "Assignment 2";
            // 
            // lblMidTermExam
            // 
            this.lblMidTermExam.AutoSize = true;
            this.lblMidTermExam.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMidTermExam.Location = new System.Drawing.Point(138, 351);
            this.lblMidTermExam.Name = "lblMidTermExam";
            this.lblMidTermExam.Size = new System.Drawing.Size(206, 31);
            this.lblMidTermExam.TabIndex = 3;
            this.lblMidTermExam.Text = "Midterm Exam";
            // 
            // lblFinalExam
            // 
            this.lblFinalExam.AutoSize = true;
            this.lblFinalExam.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinalExam.Location = new System.Drawing.Point(144, 445);
            this.lblFinalExam.Name = "lblFinalExam";
            this.lblFinalExam.Size = new System.Drawing.Size(174, 31);
            this.lblFinalExam.TabIndex = 4;
            this.lblFinalExam.Text = "Final Exam";
            // 
            // lblAssignment1TotalScore
            // 
            this.lblAssignment1TotalScore.AutoSize = true;
            this.lblAssignment1TotalScore.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssignment1TotalScore.Location = new System.Drawing.Point(647, 187);
            this.lblAssignment1TotalScore.Name = "lblAssignment1TotalScore";
            this.lblAssignment1TotalScore.Size = new System.Drawing.Size(94, 31);
            this.lblAssignment1TotalScore.TabIndex = 5;
            this.lblAssignment1TotalScore.Text = "Of 15";
            // 
            // lblAssignment2TotalScore
            // 
            this.lblAssignment2TotalScore.AutoSize = true;
            this.lblAssignment2TotalScore.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssignment2TotalScore.Location = new System.Drawing.Point(647, 262);
            this.lblAssignment2TotalScore.Name = "lblAssignment2TotalScore";
            this.lblAssignment2TotalScore.Size = new System.Drawing.Size(94, 31);
            this.lblAssignment2TotalScore.TabIndex = 6;
            this.lblAssignment2TotalScore.Text = "Of 20";
            // 
            // lblMidtermExamTotalScore
            // 
            this.lblMidtermExamTotalScore.AutoSize = true;
            this.lblMidtermExamTotalScore.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMidtermExamTotalScore.Location = new System.Drawing.Point(647, 354);
            this.lblMidtermExamTotalScore.Name = "lblMidtermExamTotalScore";
            this.lblMidtermExamTotalScore.Size = new System.Drawing.Size(94, 31);
            this.lblMidtermExamTotalScore.TabIndex = 7;
            this.lblMidtermExamTotalScore.Text = "Of 25";
            // 
            // lblFinalExamTotalScore
            // 
            this.lblFinalExamTotalScore.AutoSize = true;
            this.lblFinalExamTotalScore.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinalExamTotalScore.Location = new System.Drawing.Point(647, 445);
            this.lblFinalExamTotalScore.Name = "lblFinalExamTotalScore";
            this.lblFinalExamTotalScore.Size = new System.Drawing.Size(94, 31);
            this.lblFinalExamTotalScore.TabIndex = 8;
            this.lblFinalExamTotalScore.Text = "Of 30";
            // 
            // txtAssignment1Score
            // 
            this.txtAssignment1Score.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAssignment1Score.Location = new System.Drawing.Point(410, 186);
            this.txtAssignment1Score.Name = "txtAssignment1Score";
            this.txtAssignment1Score.Size = new System.Drawing.Size(194, 38);
            this.txtAssignment1Score.TabIndex = 9;
            // 
            // txtBoxAssignment2Score
            // 
            this.txtBoxAssignment2Score.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxAssignment2Score.Location = new System.Drawing.Point(410, 261);
            this.txtBoxAssignment2Score.Name = "txtBoxAssignment2Score";
            this.txtBoxAssignment2Score.Size = new System.Drawing.Size(194, 38);
            this.txtBoxAssignment2Score.TabIndex = 10;
            // 
            // txtMidtermExamScore
            // 
            this.txtMidtermExamScore.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMidtermExamScore.Location = new System.Drawing.Point(410, 351);
            this.txtMidtermExamScore.Name = "txtMidtermExamScore";
            this.txtMidtermExamScore.Size = new System.Drawing.Size(194, 38);
            this.txtMidtermExamScore.TabIndex = 11;
            // 
            // txtBoxFinalExamScore
            // 
            this.txtBoxFinalExamScore.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxFinalExamScore.Location = new System.Drawing.Point(410, 445);
            this.txtBoxFinalExamScore.Name = "txtBoxFinalExamScore";
            this.txtBoxFinalExamScore.Size = new System.Drawing.Size(194, 38);
            this.txtBoxFinalExamScore.TabIndex = 12;
            // 
            // lblLETTERGRADE
            // 
            this.lblLETTERGRADE.AutoSize = true;
            this.lblLETTERGRADE.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLETTERGRADE.Location = new System.Drawing.Point(273, 559);
            this.lblLETTERGRADE.Name = "lblLETTERGRADE";
            this.lblLETTERGRADE.Size = new System.Drawing.Size(206, 31);
            this.lblLETTERGRADE.TabIndex = 13;
            this.lblLETTERGRADE.Text = "LETTER GRADE";
            // 
            // txtFinalGradeLetter
            // 
            this.txtFinalGradeLetter.Location = new System.Drawing.Point(504, 559);
            this.txtFinalGradeLetter.Name = "txtFinalGradeLetter";
            this.txtFinalGradeLetter.ReadOnly = true;
            this.txtFinalGradeLetter.Size = new System.Drawing.Size(100, 31);
            this.txtFinalGradeLetter.TabIndex = 14;
            // 
            // btnFinalGradeCalculate
            // 
            this.btnFinalGradeCalculate.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalGradeCalculate.Location = new System.Drawing.Point(279, 628);
            this.btnFinalGradeCalculate.Name = "btnFinalGradeCalculate";
            this.btnFinalGradeCalculate.Size = new System.Drawing.Size(325, 125);
            this.btnFinalGradeCalculate.TabIndex = 15;
            this.btnFinalGradeCalculate.Text = "Calculate Final Grade";
            this.btnFinalGradeCalculate.UseVisualStyleBackColor = true;
            this.btnFinalGradeCalculate.Click += new System.EventHandler(this.btnFinalGradeCalculate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 765);
            this.Controls.Add(this.btnFinalGradeCalculate);
            this.Controls.Add(this.txtFinalGradeLetter);
            this.Controls.Add(this.lblLETTERGRADE);
            this.Controls.Add(this.txtBoxFinalExamScore);
            this.Controls.Add(this.txtMidtermExamScore);
            this.Controls.Add(this.txtBoxAssignment2Score);
            this.Controls.Add(this.txtAssignment1Score);
            this.Controls.Add(this.lblFinalExamTotalScore);
            this.Controls.Add(this.lblMidtermExamTotalScore);
            this.Controls.Add(this.lblAssignment2TotalScore);
            this.Controls.Add(this.lblAssignment1TotalScore);
            this.Controls.Add(this.lblFinalExam);
            this.Controls.Add(this.lblMidTermExam);
            this.Controls.Add(this.lblAssignment2);
            this.Controls.Add(this.lblAssignment1);
            this.Controls.Add(this.lblInformationSystemsDevelopment);
            this.Name = "Form1";
            this.Text = "Grade Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInformationSystemsDevelopment;
        private System.Windows.Forms.Label lblAssignment1;
        private System.Windows.Forms.Label lblAssignment2;
        private System.Windows.Forms.Label lblMidTermExam;
        private System.Windows.Forms.Label lblFinalExam;
        private System.Windows.Forms.Label lblAssignment1TotalScore;
        private System.Windows.Forms.Label lblAssignment2TotalScore;
        private System.Windows.Forms.Label lblMidtermExamTotalScore;
        private System.Windows.Forms.Label lblFinalExamTotalScore;
        private System.Windows.Forms.TextBox txtAssignment1Score;
        private System.Windows.Forms.TextBox txtBoxAssignment2Score;
        private System.Windows.Forms.TextBox txtMidtermExamScore;
        private System.Windows.Forms.TextBox txtBoxFinalExamScore;
        private System.Windows.Forms.Label lblLETTERGRADE;
        private System.Windows.Forms.TextBox txtFinalGradeLetter;
        private System.Windows.Forms.Button btnFinalGradeCalculate;
    }
}


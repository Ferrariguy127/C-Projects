﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_2_Bulin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //I double Clicked the wrong box and can't remember how to safely delete this so
            //It just kinda sits here reminding me not to do that again. -Dave
        }


        //This code is designed to take in 4 distinct scores from a user/student to help them calculate the LETTER grade they 
        //can expect at the end of the semester by adding the scores together, converting it to a percentage then comparing
        //and returning that lette (+-) to the screen.
        //It now accepts int and double answers, does not accept strings however ie 10 is not ten. 
        private void btnFinalGradeCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                // Get and validate the scores from the textboxes using individual methods
                double score1 = ValidateAssignment1Score(txtAssignment1Score.Text);  // Assignment 1 (Of 15)
                double score2 = ValidateAssignment2Score(txtBoxAssignment2Score.Text);  // Assignment 2 (Of 20)
                double midtermScore = ValidateMidtermScore(txtMidtermExamScore.Text);  // Midterm Exam (Of 25)
                double finalScore = ValidateFinalExamScore(txtBoxFinalExamScore.Text);  // Final Exam (Of 30)
                
                // Calculate the total score by adding the scores together
                double totalScore = score1 + score2 + midtermScore + finalScore;

                // Converts the score to a double for storing the percentage for use in converting to Letter Grade
                // (Total possible points = 90)
                double percentage = (double)totalScore / 90 * 100;

                // Get the corresponding letter grade based on percentage
                string letterGrade = GetLetterGrade(percentage);

                // Display the letter grade in the read-only textbox
                txtFinalGradeLetter.Text = letterGrade;
            }
            catch (Exception ex)
            {
                // Display an error message if there's an issue with input
                MessageBox.Show(ex.Message, "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //I'm sure theres a way to combine all 4 of these and give arguments on input but I have no idea on that yet.
        //-Potential option is set a value for each one like string assignment 1 total possible points 15, but I have no idea how.
        // Separate validation method for Assignment 1 (Max 15 points)
        private double ValidateAssignment1Score(string input)
        {
            double score = double.Parse(input);
            //saw on the rubric it needed to be between these values, but was unsure if it needed 15.00 or just 15 was okay. 
            //Runs fine in testing both ways so for simplicity keeping first as double and rest as just the number. 
            if (score < 0.00 || score > 15.00)
            {
                throw new ArgumentException("Assignment 1 score must be a number between 0 and 15.");
            }
            return score;
        }

        // Separate validation method for Assignment 2 (Max 20 points)
        private double ValidateAssignment2Score(string input)
        {
            double score = double.Parse(input);

            if (score < 0 || score > 20)
            {
                throw new ArgumentException("Assignment 2 score must be a number between 0 and 20.");
            }
            return score;
        }

        // Separate validation method for Midterm Exam (Max 25 points)
        private double ValidateMidtermScore(string input)
        {
            double score = double.Parse(input);

            if (score < 0 || score >25)
            {
                throw new ArgumentException("Midterm Exam score must be a number between 0 and 25.");
            }
            return score;
        }

        // Separate validation method for Final Exam (Max 30 points)
        private double ValidateFinalExamScore(string input)
        {
            // Convert input to an integer. If the conversion fails, an exception will be thrown.
            double score = double.Parse(input);

            // Check if the score is outside the allowed range.
            if (score < 0 || score > 30)
            {
                throw new ArgumentException("Final Exam score must be a number between 0 and 30.");
            }

            return score;
        }

        // Method to determine the letter grade based on total score
        //Ran into issues just passing if statements system got hung up in testing. 
        private string GetLetterGrade(double percentage)
        {
            if (percentage >= 93) return "A";
            else if (percentage >= 90) return "A-";
            else if (percentage >= 87) return "B+";
            else if (percentage >= 83) return "B";
            else if (percentage >= 80) return "B-";
            else if (percentage >= 77) return "C+";
            else if (percentage >= 73) return "C";
            else if (percentage >= 70) return "C-";
            else if (percentage >= 67) return "D+";
            else if (percentage >= 63) return "D";
            else if (percentage >= 60) return "D-";
            else return "F";
        }
    }
}

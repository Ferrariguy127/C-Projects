﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IS304_Assignment_4
{
    public partial class Form1 : Form
    {// Data for the sales report
        private readonly string[] products = { "iPhone 14 Plus", "Google Pixel 7 Pro", "Moto G 5G", "Nokia XR20 5G", "Samsung Galaxy S21" };
        private readonly decimal[] prices = { 800.00m, 750.00m, 200.00m, 450.00m, 600.00m };
        private readonly int[,] salesData = {
            //Each of the categories are for each location,
            // Eau Claire, Chippewa Falls, Menomonie
            { 200, 100, 120 },  //iphone 14 plus
            { 220, 60, 50 },    //Google Pixel 7 Pro
            { 80, 25, 75 },     //Moto G 5G
            { 150, 60, 126 },   //Nokia XR20 5G
            { 75, 20, 65 }      //Samsung Galaxy S21
        };
        public Form1()
        {
            InitializeComponent();
        }

        private void btnViewSalesReport_Click(object sender, EventArgs e)
        {
            // Determine the selected location
            int locationIndex = -1; //Default value is -1 as 0 is actually the start of the Groupbox. -1 is null as it cannot be selected. 
            if (RdbEauClaire.Checked) locationIndex = 0;
            else if (rdbtnChippewa.Checked) locationIndex = 1;
            else if (rdbtnMenomonie.Checked) locationIndex = 2;

            // 1 Point, if no location is displayed show error code
            if (locationIndex == -1)
            {
                MessageBox.Show("Please select a location.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            // Clear the ListBox
            ListboxOutput.Items.Clear();

            // Add header
            string locationName = locationIndex == 0 ? "Eau Claire" : locationIndex == 1 ? "Chippewa Falls" : "Menomonie";
            ListboxOutput.Items.Add($"---------- Sales Report for {locationName} --------------");
            ListboxOutput.Items.Add(string.Format("{0,-25}{1,10}{2,15}", "Product Name", "Quantity", "Sub Total"));
            ListboxOutput.Items.Add("----------------------------------------------------");

            // Generate report
            //In the final report it takes the values from each index array and multiplies it by the index position of the cost of each phone.
            //Initial value for the grand total is set to 0 and adjusted each time as needed. 
            decimal grandTotal = 0;

            //In order to calculate each phones total sale amount it needs to run through a for loop and add each total cost into the grand total. 
            for (int i = 0; i < products.Length; i++)
            {
                int quantity = salesData[i, locationIndex];
                decimal subtotal = quantity * prices[i];//This takes the price and multiplies it by the number of phones available. 
                grandTotal += subtotal;

                // Add product details in formatted style
                ListboxOutput.Items.Add(string.Format("{0,-25}{1,10}{2,15:C}", products[i], quantity, subtotal));
            }

            // Add grand total
            ListboxOutput.Items.Add("----------------------------------------------------");
            ListboxOutput.Items.Add(string.Format("{0,-25}{1,10}{2,15:C}", "Grand Total", "", grandTotal));
        }
    }
}

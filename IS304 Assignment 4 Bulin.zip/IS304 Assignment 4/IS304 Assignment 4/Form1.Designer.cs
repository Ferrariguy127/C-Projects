﻿namespace IS304_Assignment_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GBLocSel = new System.Windows.Forms.GroupBox();
            this.RdbEauClaire = new System.Windows.Forms.RadioButton();
            this.rdbtnChippewa = new System.Windows.Forms.RadioButton();
            this.rdbtnMenomonie = new System.Windows.Forms.RadioButton();
            this.ListboxOutput = new System.Windows.Forms.ListBox();
            this.btnViewSalesReport = new System.Windows.Forms.Button();
            this.GBLocSel.SuspendLayout();
            this.SuspendLayout();
            // 
            // GBLocSel
            // 
            this.GBLocSel.Controls.Add(this.rdbtnMenomonie);
            this.GBLocSel.Controls.Add(this.rdbtnChippewa);
            this.GBLocSel.Controls.Add(this.RdbEauClaire);
            this.GBLocSel.Location = new System.Drawing.Point(74, 84);
            this.GBLocSel.Name = "GBLocSel";
            this.GBLocSel.Size = new System.Drawing.Size(369, 392);
            this.GBLocSel.TabIndex = 2;
            this.GBLocSel.TabStop = false;
            this.GBLocSel.Text = "Select A Location";
            // 
            // RdbEauClaire
            // 
            this.RdbEauClaire.AutoSize = true;
            this.RdbEauClaire.Location = new System.Drawing.Point(44, 64);
            this.RdbEauClaire.Name = "RdbEauClaire";
            this.RdbEauClaire.Size = new System.Drawing.Size(204, 34);
            this.RdbEauClaire.TabIndex = 0;
            this.RdbEauClaire.TabStop = true;
            this.RdbEauClaire.Text = "Eau Claire";
            this.RdbEauClaire.UseVisualStyleBackColor = true;
            // 
            // rdbtnChippewa
            // 
            this.rdbtnChippewa.AutoSize = true;
            this.rdbtnChippewa.Location = new System.Drawing.Point(44, 132);
            this.rdbtnChippewa.Name = "rdbtnChippewa";
            this.rdbtnChippewa.Size = new System.Drawing.Size(268, 34);
            this.rdbtnChippewa.TabIndex = 1;
            this.rdbtnChippewa.TabStop = true;
            this.rdbtnChippewa.Text = "Chippewa Falls";
            this.rdbtnChippewa.UseVisualStyleBackColor = true;
            // 
            // rdbtnMenomonie
            // 
            this.rdbtnMenomonie.AutoSize = true;
            this.rdbtnMenomonie.Location = new System.Drawing.Point(44, 197);
            this.rdbtnMenomonie.Name = "rdbtnMenomonie";
            this.rdbtnMenomonie.Size = new System.Drawing.Size(188, 34);
            this.rdbtnMenomonie.TabIndex = 2;
            this.rdbtnMenomonie.TabStop = true;
            this.rdbtnMenomonie.Text = "Menomonie";
            this.rdbtnMenomonie.UseVisualStyleBackColor = true;
            // 
            // ListboxOutput
            // 
            this.ListboxOutput.FormattingEnabled = true;
            this.ListboxOutput.ItemHeight = 30;
            this.ListboxOutput.Location = new System.Drawing.Point(589, 84);
            this.ListboxOutput.Name = "ListboxOutput";
            this.ListboxOutput.Size = new System.Drawing.Size(424, 394);
            this.ListboxOutput.TabIndex = 3;
            // 
            // btnViewSalesReport
            // 
            this.btnViewSalesReport.Location = new System.Drawing.Point(74, 515);
            this.btnViewSalesReport.Name = "btnViewSalesReport";
            this.btnViewSalesReport.Size = new System.Drawing.Size(369, 136);
            this.btnViewSalesReport.TabIndex = 4;
            this.btnViewSalesReport.Text = "View Sales Report";
            this.btnViewSalesReport.UseVisualStyleBackColor = true;
            this.btnViewSalesReport.Click += new System.EventHandler(this.btnViewSalesReport_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1283, 738);
            this.Controls.Add(this.btnViewSalesReport);
            this.Controls.Add(this.ListboxOutput);
            this.Controls.Add(this.GBLocSel);
            this.Font = new System.Drawing.Font("Courier New", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Cell Phone Sales Report By Location";
            this.GBLocSel.ResumeLayout(false);
            this.GBLocSel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GBLocSel;
        private System.Windows.Forms.RadioButton rdbtnMenomonie;
        private System.Windows.Forms.RadioButton rdbtnChippewa;
        private System.Windows.Forms.RadioButton RdbEauClaire;
        private System.Windows.Forms.ListBox ListboxOutput;
        private System.Windows.Forms.Button btnViewSalesReport;
    }
}

